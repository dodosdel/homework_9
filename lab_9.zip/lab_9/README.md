# lab_9

Continue working on this project.

## Task

1. Create another screen (e.g.: MainScreen())
2. Design main screen with proper paddings, borders and etc...
3. read the data from 'user.db' to fill out user information which should include:
        a. various Text() widgets for Username, Phone, address and email and their data taken from the db!